"""FastAPI-приложение «Портрет личности».
Запуск:  uvicorn portrait.api:app --reload
Документация (Swagger):  http://127.0.0.1:8000/docs
"""
from pathlib import Path
from typing import Dict

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

from . import service

app = FastAPI(title="Портрет личности", version="1.0",
              description="Модуль психологического тестирования: опрос, подсчёт по ключам, отчёт.")

STATIC = Path(__file__).parent / "static"


class PortraitRequest(BaseModel):
    # {"rosenberg": {"ros_1": 3, ...}, "pss10": {...}}
    answers: Dict[str, Dict[str, int]]


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(STATIC / "index.html")


@app.get("/api/methods")
def methods():
    """Список подключённых методик."""
    return service.list_methods()


@app.get("/api/methods/{method_id}/questions")
def questions(method_id: str):
    """Вопросы и варианты ответа методики (без ключей подсчёта)."""
    try:
        return service.get_questions(method_id)
    except service.UnknownMethod:
        raise HTTPException(status_code=404, detail=f"Методика {method_id!r} не найдена")


@app.post("/api/portrait")
def portrait(req: PortraitRequest):
    """Принимает ответы, возвращает «Портрет личности» (JSON)."""
    try:
        return service.compute_portrait(req.answers)
    except service.UnknownMethod as e:
        raise HTTPException(status_code=422, detail=f"Неизвестная методика: {e.args[0]!r}")


@app.get("/api/validate")
def validation():
    """Результат валидатора (сверка ключей с эталоном)."""
    return service.run_validation()

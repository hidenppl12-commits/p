"""Универсальный подсчёт баллов по ключам + проверка достоверности."""
from statistics import mean


class ScoringError(Exception):
    pass


class IncompleteAnswers(ScoringError):
    pass


class InvalidAnswer(ScoringError):
    pass


def keyed_value(spec, q, answer):
    """Балл с учётом ключа (обратный пункт переворачивается)."""
    return spec.min_value + spec.max_value - answer if q.reverse else answer


def max_raw(spec, key):
    return len(spec.questions_of(key)) * spec.max_value


def min_raw(spec, key):
    return len(spec.questions_of(key)) * spec.min_value


def check_validity(spec, answers):
    """Предупреждения о недостоверных ответах (не ломают результат)."""
    warns = []
    vals = [answers[q.id] for q in spec.questions]
    if len(vals) >= 8 and len(set(vals)) == 1:
        warns.append("Все ответы одинаковые — результат, вероятно, недостоверен.")
    span = spec.max_value - spec.min_value
    for sc in spec.scales:
        qs = spec.questions_of(sc.key)
        direct = [answers[q.id] for q in qs if not q.reverse]
        rev = [keyed_value(spec, q, answers[q.id]) for q in qs if q.reverse]
        if direct and rev and abs(mean(direct) - mean(rev)) > 0.4 * span:
            warns.append(
                f"Шкала «{sc.title}»: прямые и обратные вопросы отвечены "
                f"противоречиво (возможна невнимательность).")
    return warns


def score_method(spec, answers):
    valid = {v for v, _ in spec.options}
    missing = [q.id for q in spec.questions if q.id not in answers]
    if missing:
        raise IncompleteAnswers(
            f"Нет ответов на {len(missing)} из {len(spec.questions)} вопросов "
            f"(первый: {missing[0]}).")
    for q in spec.questions:
        if answers[q.id] not in valid:
            raise InvalidAnswer(f"Вопрос {q.id}: недопустимый ответ {answers[q.id]!r}.")
    scales = {}
    for sc in spec.scales:
        qs = spec.questions_of(sc.key)
        raw = sum(keyed_value(spec, q, answers[q.id]) for q in qs)
        lo, hi = min_raw(spec, sc.key), max_raw(spec, sc.key)
        band = next(b for b in sc.bands if raw <= b.max_raw)
        scales[sc.key] = {
            "title": sc.title, "raw": raw, "min": lo, "max": hi,
            "percent": round((raw - lo) / (hi - lo) * 100, 1),
            "level": band.label, "interpretation": band.text,
        }
    return {"method_id": spec.id, "number": spec.number, "title": spec.title,
            "status": "ok", "scales": scales,
            "warnings": check_validity(spec, answers)}

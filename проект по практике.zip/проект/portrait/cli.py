"""Консольный интерфейс: опрос с прогрессом, возвратом назад и отчётом."""
import json
import random
from .engine import SurveyEngine
from .methods import REGISTRY
from .collector import build_portrait, render_text
from .validator import validate
from .scoring import keyed_value


def simulate(spec, targets, rng):
    """Синтетический респондент: targets[шкала] ∈ [0,1] — выраженность черты."""
    ans = {}
    for q in spec.questions:
        t = min(1, max(0, targets[q.scale] + rng.uniform(-0.12, 0.12)))
        v = round(spec.min_value + t * (spec.max_value - spec.min_value))
        ans[q.id] = keyed_value(spec, q, v)   # переворот обратных пунктов
    return ans


def run_interactive():
    eng = SurveyEngine(REGISTRY)
    last = None
    while not eng.finished:
        spec, q = eng.current()
        if spec.id != last:
            print(f"\n=== {spec.title} ===\n{spec.instruction}")
            last = spec.id
        done, total = eng.progress()
        bar = "█" * int(20 * done / total) + "░" * (20 - int(20 * done / total))
        print(f"\n[{bar}] {done + 1}/{total}\n{q.text}")
        for i, (_, label) in enumerate(spec.options, 1):
            print(f"  {i}. {label}")
        raw = input("Ответ (номер, b — назад): ").strip().lower()
        if raw == "b":
            eng.back()
            last = None
        elif raw.isdigit() and 1 <= int(raw) <= len(spec.options):
            eng.answer(spec.options[int(raw) - 1][0])
        else:
            print("Введите номер варианта.")
    return eng.answers_by_method()


def main(argv):
    cmd = argv[0] if argv else "run"
    if cmd == "validate":
        raise SystemExit(1 if validate() else 0)
    if cmd == "serve":
        import uvicorn
        uvicorn.run("portrait.api:app", host="127.0.0.1", port=8000)
        return
    if cmd == "demo":
        rng = random.Random(42)
        prof = {"E": .8, "A": .6, "C": .3, "N": .7, "O": .9, "SE": .45, "PS": .8}
        answers = {s.id: simulate(s, prof, rng) for s in REGISTRY}
    elif cmd == "run":
        answers = run_interactive()
    else:
        print("Команды: run | demo | validate | serve"); return
    p = build_portrait(REGISTRY, answers)
    print("\n" + render_text(p))
    with open("portrait.json", "w", encoding="utf-8") as f:
        json.dump(p, f, ensure_ascii=False, indent=2)
    print("JSON-отчёт сохранён: portrait.json")

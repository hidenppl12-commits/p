"""Реестр методик. Новая методика = новый файл + строка здесь."""
from .rosenberg import SPEC as ROSENBERG
from .bigfive import SPEC as BIGFIVE
from .pss10 import SPEC as PSS10

REGISTRY = [ROSENBERG, BIGFIVE, PSS10]

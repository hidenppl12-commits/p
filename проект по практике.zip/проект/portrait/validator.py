"""Валидатор: проверяет, что ничего не забыто, и сверяет КАЖДЫЙ вопрос
с эталонными ключами из reference_keys.py."""
from .methods import REGISTRY
from .collector import TOTAL_PLANNED
from .reference_keys import expected_map
from .scoring import score_method


def validate(specs=None, verbose=True):
    specs = REGISTRY if specs is None else specs
    problems, lines = [], []
    ref = expected_map()

    ids = [s.id for s in specs]
    nums = [s.number for s in specs]
    if len(ids) != len(set(ids)):
        problems.append("Дубликаты id методик")
    if len(nums) != len(set(nums)):
        problems.append("Дубликаты номеров методик")
    if any(not 1 <= n <= TOTAL_PLANNED for n in nums):
        problems.append(f"Номер методики вне диапазона 1..{TOTAL_PLANNED}")
    lines.append(f"Методик подключено: {len(specs)} из {TOTAL_PLANNED}"
                 + ("" if len(specs) == TOTAL_PLANNED else "  (остальные ещё не добавлены)"))

    checked = 0
    for s in specs:
        lines.append(f"\n=== [{s.number}] {s.title} ===")
        qids = [q.id for q in s.questions]
        if len(qids) != len(set(qids)):
            problems.append(f"{s.id}: дубликаты id вопросов")
        texts = [q.text for q in s.questions]
        if len(texts) != len(set(texts)) or any(not t.strip() for t in texts):
            problems.append(f"{s.id}: пустые или повторяющиеся тексты вопросов")
        vals = sorted(v for v, _ in s.options)
        if len(vals) < 2 or vals != list(range(vals[0], vals[0] + len(vals))):
            problems.append(f"{s.id}: значения вариантов ответа не идут подряд")
        keys = {sc.key for sc in s.scales}
        for q in s.questions:
            if q.scale not in keys:
                problems.append(f"{s.id}/{q.id}: шкала {q.scale!r} не объявлена")
        for sc in s.scales:
            n = len(s.questions_of(sc.key))
            if n == 0:
                problems.append(f"{s.id}/{sc.key}: в шкале нет вопросов")
                continue
            top = n * s.max_value
            mx = [b.max_raw for b in sc.bands]
            if mx != sorted(set(mx)) or mx[-1] != top:
                problems.append(f"{s.id}/{sc.key}: диапазоны интерпретации не покрывают 0..{top}")
            if any(not b.text.strip() for b in sc.bands):
                problems.append(f"{s.id}/{sc.key}: пустая интерпретация")

        # --- сверка каждого вопроса с эталоном ---
        etalon = ref.get(s.id)
        if etalon is None:
            problems.append(f"{s.id}: нет эталонных ключей для сверки")
            continue
        if set(etalon) != set(qids):
            problems.append(f"{s.id}: набор вопросов не совпадает с эталоном "
                            f"(лишние/потерянные: {sorted(set(etalon) ^ set(qids))})")
        for q in s.questions:
            checked += 1
            e = etalon.get(q.id)
            ok = e is not None and e[0] == q.scale and (e[1] == "-") == q.reverse
            if not ok:
                problems.append(f"{s.id}/{q.id}: ключ НЕ совпадает с эталоном "
                                f"(в коде: {q.scale}{'-' if q.reverse else '+'}, эталон: {e})")
            lines.append(f"  {'OK ' if ok else 'ERR'} {q.id:8} шкала {q.scale:3} "
                         f"{'обратный' if q.reverse else 'прямой  '}  {q.text[:55]}")

        # --- контрольные прогоны: все минимальные / все максимальные ---
        for label, v in (("все ответы = мин", s.min_value), ("все ответы = макс", s.max_value)):
            res = score_method(s, {q.id: v for q in s.questions})
            for sc in s.scales:
                signs = [etalon[q.id][1] for q in s.questions_of(sc.key)]
                exp = sum(v if sg == "+" else s.min_value + s.max_value - v for sg in signs)
                got = res["scales"][sc.key]["raw"]
                if got != exp:
                    problems.append(f"{s.id}/{sc.key} ({label}): получено {got}, ожидалось {exp}")
                lines.append(f"  контроль [{label}] {sc.key}: {got} (эталон {exp})")

    lines.append(f"\nСверено вопросов: {checked}. Проблем: {len(problems)}")
    for p in problems:
        lines.append("  ✗ " + p)
    if verbose:
        print("\n".join(lines))
    return problems

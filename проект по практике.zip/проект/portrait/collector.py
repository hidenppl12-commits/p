"""Сборщик результатов: склеивает методики в «Портрет личности».
Сбой одной методики не роняет весь отчёт."""
from datetime import datetime
from .scoring import score_method, ScoringError

TOTAL_PLANNED = 20


def build_portrait(specs, answers_by_method):
    results = []
    for spec in specs:
        try:
            results.append(score_method(spec, answers_by_method.get(spec.id, {})))
        except ScoringError as e:
            results.append({"method_id": spec.id, "number": spec.number,
                            "title": spec.title, "status": "incomplete",
                            "error": str(e)})
        except Exception as e:  # баг в самой методике
            results.append({"method_id": spec.id, "number": spec.number,
                            "title": spec.title, "status": "crashed",
                            "error": f"{type(e).__name__}: {e}"})
    ok = [r for r in results if r["status"] == "ok"]
    headline = []
    for r in ok:
        for s in r["scales"].values():
            headline.append(f"{s['title']}: {s['level']} ({s['raw']} из {s['max']})")
    return {
        "portrait_version": "1.0",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "summary": {"methods_planned": TOTAL_PLANNED, "methods_connected": len(specs),
                    "ok": len(ok), "failed": len(results) - len(ok)},
        "headline": headline,
        "methods": results,
    }


def render_text(p):
    s = p["summary"]
    L = ["=" * 60, "ПОРТРЕТ ЛИЧНОСТИ", "=" * 60,
         f"Методик подключено: {s['methods_connected']} из {s['methods_planned']}; "
         f"успешно: {s['ok']}, с ошибкой: {s['failed']}", ""]
    for r in p["methods"]:
        L.append(f"[{r['number']}] {r['title']}")
        if r["status"] != "ok":
            L.append(f"   ! {r['status']}: {r['error']}\n")
            continue
        for s_ in r["scales"].values():
            L.append(f"   • {s_['title']}: {s_['raw']}/{s_['max']} "
                     f"({s_['percent']}%) — {s_['level']}")
            L.append(f"     {s_['interpretation']}")
        for w in r["warnings"]:
            L.append(f"   ⚠ {w}")
        L.append("")
    return "\n".join(L)

"""Движок опроса: не знает, какие это тесты — только показывает вопросы
по одному, принимает ответы, умеет возвращаться назад."""
from .scoring import InvalidAnswer


class SurveyEngine:
    def __init__(self, specs):
        self.items = [(s, q) for s in specs for q in s.questions]
        keys = [(s.id, q.id) for s, q in self.items]
        if len(keys) != len(set(keys)):
            raise ValueError("Дубликаты вопросов в методиках")
        self.pos = 0
        self._answers = {}

    @property
    def total(self):
        return len(self.items)

    @property
    def finished(self):
        return self.pos >= self.total

    def current(self):
        """(методика, вопрос) или None, если опрос окончен."""
        return None if self.finished else self.items[self.pos]

    def answer(self, value):
        spec, q = self.current()
        if value not in {v for v, _ in spec.options}:
            raise InvalidAnswer(f"Недопустимый ответ {value!r} на {q.id}")
        self._answers[(spec.id, q.id)] = value
        self.pos += 1

    def back(self):
        if self.pos > 0:
            self.pos -= 1

    def progress(self):
        return self.pos, self.total

    def answers_by_method(self):
        out = {}
        for (mid, qid), v in self._answers.items():
            out.setdefault(mid, {})[qid] = v
        return out

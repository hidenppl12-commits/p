"""Слой сервиса: вся логика API без привязки к веб-фреймворку.
api.py — тонкая обёртка над этими функциями (их можно тестировать без FastAPI)."""
from .methods import REGISTRY
from .collector import build_portrait, TOTAL_PLANNED
from .validator import validate


class UnknownMethod(KeyError):
    pass


def _spec(method_id):
    for s in REGISTRY:
        if s.id == method_id:
            return s
    raise UnknownMethod(method_id)


def list_methods():
    return {
        "planned": TOTAL_PLANNED,
        "connected": len(REGISTRY),
        "methods": [{"id": s.id, "number": s.number, "title": s.title,
                     "instruction": s.instruction,
                     "question_count": len(s.questions)} for s in REGISTRY],
    }


def get_questions(method_id):
    """Вопросы для клиента. Ключи (шкала, обратность) НЕ отдаём —
    клиент не должен знать, как считается результат."""
    s = _spec(method_id)
    return {
        "id": s.id, "title": s.title, "instruction": s.instruction,
        "options": [{"value": v, "label": l} for v, l in s.options],
        "questions": [{"id": q.id, "text": q.text} for q in s.questions],
    }


def compute_portrait(answers):
    """answers: {method_id: {question_id: value}}. Неизвестная методика -> UnknownMethod."""
    known = {s.id for s in REGISTRY}
    for mid in answers:
        if mid not in known:
            raise UnknownMethod(mid)
    return build_portrait(REGISTRY, answers)


def run_validation():
    problems = validate(verbose=False)
    return {"ok": not problems, "problems": problems, "methods_checked": len(REGISTRY)}

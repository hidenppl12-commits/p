"""ЭТАЛОННЫЕ ключи из источников методик — независимая копия для сверки.
'+' — прямой пункт, '-' — обратный. Порядок — по номеру пункта внутри шкалы."""

BIGFIVE = {"E": "+-+-+-+-+-", "A": "-+-+-+-+++", "C": "+-+-+-+-++",
           "N": "+-+-++++++", "O": "+-+-+-++++"}
ROSENBERG = {"SE": "++-+-++---"}
PSS10 = {"PS": "+++--+--++"}


def expected_map():
    """{method_id: {question_id: (scale, sign)}}"""
    out = {"bigfive": {}, "rosenberg": {}, "pss10": {}}
    for t, signs in BIGFIVE.items():
        for i, s in enumerate(signs):
            out["bigfive"][f"bf_{t}{i+1}"] = (t, s)
    for i, s in enumerate(ROSENBERG["SE"]):
        out["rosenberg"][f"ros_{i+1}"] = ("SE", s)
    for i, s in enumerate(PSS10["PS"]):
        out["pss10"][f"pss_{i+1}"] = ("PS", s)
    return out

"""Контракты данных: как ядро общается с методиками."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Question:
    id: str            # уникален внутри методики
    text: str
    scale: str         # ключ шкалы, в которую идёт балл
    reverse: bool = False   # обратный ключ: балл = min + max - ответ


@dataclass(frozen=True)
class Band:
    max_raw: int       # верхняя граница (включительно) в сырых баллах
    label: str
    text: str          # интерпретация


@dataclass(frozen=True)
class Scale:
    key: str
    title: str
    bands: tuple       # Band по возрастанию max_raw


@dataclass(frozen=True)
class MethodSpec:
    id: str
    number: int        # номер методики из списка 1..20
    title: str
    instruction: str
    options: tuple     # ((значение, подпись), ...)
    questions: tuple
    scales: tuple

    @property
    def min_value(self):
        return min(v for v, _ in self.options)

    @property
    def max_value(self):
        return max(v for v, _ in self.options)

    def questions_of(self, key):
        return [q for q in self.questions if q.scale == key]

    def scale(self, key):
        return next(s for s in self.scales if s.key == key)

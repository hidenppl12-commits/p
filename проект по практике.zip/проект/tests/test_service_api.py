import unittest, importlib.util
from portrait import service
from portrait.methods import REGISTRY

HAS_FASTAPI = (importlib.util.find_spec("fastapi") is not None
               and importlib.util.find_spec("httpx") is not None)


def full_answers():
    return {s.id: {q.id: s.options[-1][0] for q in s.questions} for s in REGISTRY}


class TestService(unittest.TestCase):
    def test_methods(self):
        m = service.list_methods()
        self.assertEqual((m["planned"], m["connected"]), (20, 3))

    def test_questions_hide_keys(self):
        d = service.get_questions("rosenberg")
        self.assertEqual(len(d["questions"]), 10)
        for q in d["questions"]:
            self.assertEqual(set(q), {"id", "text"})     # ни шкалы, ни reverse

    def test_unknown_method(self):
        with self.assertRaises(service.UnknownMethod):
            service.get_questions("nope")
        with self.assertRaises(service.UnknownMethod):
            service.compute_portrait({"nope": {}})

    def test_portrait_and_partial(self):
        self.assertEqual(service.compute_portrait(full_answers())["summary"]["ok"], 3)
        a = full_answers(); del a["pss10"]
        self.assertEqual(service.compute_portrait(a)["summary"]["failed"], 1)

    def test_validation(self):
        self.assertTrue(service.run_validation()["ok"])


@unittest.skipUnless(HAS_FASTAPI, "fastapi/httpx не установлены: pip install -r requirements.txt")
class TestApi(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fastapi.testclient import TestClient
        from portrait.api import app
        cls.c = TestClient(app)

    def test_index_page(self):
        r = self.c.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn("Портрет личности", r.text)

    def test_methods_and_questions(self):
        self.assertEqual(self.c.get("/api/methods").json()["connected"], 3)
        self.assertEqual(len(self.c.get("/api/methods/bigfive/questions").json()["questions"]), 50)
        self.assertEqual(self.c.get("/api/methods/nope/questions").status_code, 404)

    def test_portrait(self):
        r = self.c.post("/api/portrait", json={"answers": full_answers()})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["summary"]["ok"], 3)

    def test_portrait_errors(self):
        self.assertEqual(self.c.post("/api/portrait", json={"answers": {"nope": {}}}).status_code, 422)
        self.assertEqual(self.c.post("/api/portrait", json={"answers": "x"}).status_code, 422)

    def test_validate(self):
        self.assertTrue(self.c.get("/api/validate").json()["ok"])


if __name__ == "__main__":
    unittest.main()

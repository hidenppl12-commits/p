import unittest, random, copy
from portrait.methods import REGISTRY
from portrait.methods.rosenberg import SPEC as ROS
from portrait.methods.pss10 import SPEC as PSS
from portrait.methods.bigfive import SPEC as BF
from portrait.engine import SurveyEngine
from portrait.scoring import score_method, InvalidAnswer, IncompleteAnswers
from portrait.collector import build_portrait
from portrait.validator import validate
from portrait.cli import simulate


def uniform(spec, v):
    return {q.id: v for q in spec.questions}


class TestKeys(unittest.TestCase):
    def test_validator_clean(self):
        self.assertEqual(validate(verbose=False), [])

    def test_validator_catches_wrong_key(self):
        bad = copy.deepcopy(ROS)
        qs = list(bad.questions)
        q = qs[2]                                    # пункт 3 должен быть обратным
        qs[2] = type(q)(q.id, q.text, q.scale, False)
        object.__setattr__(bad, "questions", tuple(qs))
        self.assertTrue(any("ros_3" in p for p in validate([bad], verbose=False)))


class TestHandCalculated(unittest.TestCase):
    """Значения посчитаны вручную, не кодом."""
    def test_rosenberg_extremes(self):
        for v, level in ((0, "нормальный"), (3, "нормальный")):
            r = score_method(ROS, uniform(ROS, v))["scales"]["SE"]
            self.assertEqual(r["raw"], 15)           # 5 прямых + 5 обратных
            self.assertEqual(r["level"], level)

    def test_rosenberg_best_and_worst(self):
        best = dict(zip([q.id for q in ROS.questions], [3,3,0,3,0,3,3,0,0,0]))
        worst = dict(zip([q.id for q in ROS.questions], [0,0,3,0,3,0,0,3,3,3]))
        self.assertEqual(score_method(ROS, best)["scales"]["SE"]["raw"], 30)
        self.assertEqual(score_method(ROS, best)["scales"]["SE"]["level"], "высокий")
        self.assertEqual(score_method(ROS, worst)["scales"]["SE"]["raw"], 0)
        self.assertEqual(score_method(ROS, worst)["scales"]["SE"]["level"], "низкий")

    def test_rosenberg_mixed(self):
        a = dict(zip([q.id for q in ROS.questions], [2,2,1,2,1,2,2,1,1,1]))
        self.assertEqual(score_method(ROS, a)["scales"]["SE"]["raw"], 20)  # 10 + 5*2

    def test_pss_extremes(self):
        self.assertEqual(score_method(PSS, uniform(PSS, 0))["scales"]["PS"]["raw"], 16)
        self.assertEqual(score_method(PSS, uniform(PSS, 4))["scales"]["PS"]["raw"], 24)

    def test_pss_boundaries(self):
        # прямые=0, обратные=4 → стресс 0 → «низкий»
        a = {q.id: (4 if q.reverse else 0) for q in PSS.questions}
        r = score_method(PSS, a)["scales"]["PS"]
        self.assertEqual((r["raw"], r["level"]), (0, "низкий"))
        a = {q.id: (0 if q.reverse else 4) for q in PSS.questions}
        r = score_method(PSS, a)["scales"]["PS"]
        self.assertEqual((r["raw"], r["level"]), (40, "высокий"))

    def test_bigfive_all_min_all_max(self):
        mn = {"E": 30, "A": 26, "C": 26, "N": 18, "O": 22}
        mx = {"E": 30, "A": 34, "C": 34, "N": 42, "O": 38}
        for v, exp in ((1, mn), (5, mx)):
            sc = score_method(BF, uniform(BF, v))["scales"]
            for k, e in exp.items():
                self.assertEqual(sc[k]["raw"], e, f"{k} при ответах {v}")


class TestRoundTrip(unittest.TestCase):
    def test_simulated_profile_recovered(self):
        rng = random.Random(1)
        prof = {"E": .9, "A": .1, "C": .5, "N": .9, "O": .1}
        sc = score_method(BF, simulate(BF, prof, rng))["scales"]
        self.assertEqual(sc["E"]["level"], "высокий")
        self.assertEqual(sc["A"]["level"], "низкий")
        self.assertEqual(sc["N"]["level"], "высокий")
        self.assertEqual(sc["O"]["level"], "низкий")


class TestRobustness(unittest.TestCase):
    def test_invalid_and_incomplete(self):
        with self.assertRaises(IncompleteAnswers):
            score_method(ROS, {"ros_1": 1})
        a = uniform(ROS, 1); a["ros_1"] = 9
        with self.assertRaises(InvalidAnswer):
            score_method(ROS, a)

    def test_straightlining_warning(self):
        self.assertTrue(score_method(BF, uniform(BF, 3))["warnings"])

    def test_inconsistency_warning(self):
        # прямые = 5, обратные тоже 5 (т.е. «за» и «против» одновременно)
        r = score_method(ROS, uniform(ROS, 3))
        self.assertTrue(any("противоречиво" in w for w in r["warnings"]))

    def test_one_broken_method_does_not_break_portrait(self):
        answers = {s.id: uniform(s, s.min_value) for s in REGISTRY}
        del answers["pss10"]
        p = build_portrait(REGISTRY, answers)
        st = {m["method_id"]: m["status"] for m in p["methods"]}
        self.assertEqual(st["pss10"], "incomplete")
        self.assertEqual(st["rosenberg"], "ok")
        self.assertEqual(p["summary"]["failed"], 1)

    def test_crashing_method_is_isolated(self):
        broken = copy.deepcopy(ROS)
        object.__setattr__(broken, "scales", ())    # баг: шкалы потеряны
        object.__setattr__(broken, "id", "broken")
        object.__setattr__(broken, "number", 9)
        p = build_portrait([broken, PSS], {"broken": uniform(ROS, 1), "pss10": uniform(PSS, 1)})
        self.assertEqual(p["methods"][1]["status"], "ok")


class TestEngine(unittest.TestCase):
    def test_flow_back_progress(self):
        e = SurveyEngine(REGISTRY)
        self.assertEqual(e.total, 70)
        spec, q = e.current()
        e.answer(spec.options[0][0]); e.answer(spec.options[1][0])
        self.assertEqual(e.progress(), (2, 70))
        e.back()
        self.assertEqual(e.progress(), (1, 70))
        with self.assertRaises(InvalidAnswer):
            e.answer(99)

    def test_full_pass(self):
        e = SurveyEngine(REGISTRY)
        while not e.finished:
            spec, q = e.current()
            e.answer(spec.options[-1][0])
        p = build_portrait(REGISTRY, e.answers_by_method())
        self.assertEqual(p["summary"]["ok"], 3)


if __name__ == "__main__":
    unittest.main()
